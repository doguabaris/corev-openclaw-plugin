# Changelog

## v0.1.0-alpha.1 / 2026-03-23
- Initial release
